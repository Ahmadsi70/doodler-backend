#!/bin/bash
set -e

echo "Downloading Meta's AnimatedDrawings..."
git clone https://github.com/facebookresearch/AnimatedDrawings.git
cd AnimatedDrawings

# The setup.py or requirements in AnimatedDrawings might be old, but we have our own requirements.
# We will just make sure the models/weights are downloaded. 
# (AnimatedDrawings handles weights download on first run)

cd ..

echo "Setting up AudioLDM for SFX..."
# Diffusers handles AudioLDM weight downloads on first run, no manual cloning needed.

echo "Setup complete."
